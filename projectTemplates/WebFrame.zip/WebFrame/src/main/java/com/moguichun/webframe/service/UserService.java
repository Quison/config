package com.moguichun.webframe.service;

import com.moguichun.webframe.model.User;

import java.util.List;

/**
 * Created by MoGuichun on 2016-7-15.
 */
public interface UserService {

    public List<User> getAllUser();

}
