package com.moguichun.webframe.dao;

import com.moguichun.webframe.model.User;

import java.util.List;

/**
 * Created by MoGuichun on 2016-7-14.
 */
public interface UserDao {

    public List<User> getAllUser();

}
