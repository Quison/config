-- --------------------------------------------------------
-- 主机:                           172.20.4.235
-- 服务器版本:                        5.5.8-log - Source distribution
-- 服务器操作系统:                      Linux
-- HeidiSQL 版本:                  9.3.0.5055
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- 导出 KKBUSINESS 的数据库结构
CREATE DATABASE IF NOT EXISTS `KKBUSINESS` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `KKBUSINESS`;

-- 导出  表 KKBUSINESS.childmode_config 结构
CREATE TABLE IF NOT EXISTS `childmode_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键，自增id',
  `openid` varchar(100) NOT NULL COMMENT '管理员的openid',
  `deviceid` int(11) NOT NULL COMMENT '设备id',
  `mode` tinyint(4) NOT NULL DEFAULT '0' COMMENT '模式，0 = 普通模式、1 = 儿童模式',
  `watch_start_time` varchar(10) NOT NULL DEFAULT '00:00' COMMENT '观看时段开始时间 ，00:00~23:59',
  `watch_end_time` varchar(10) NOT NULL DEFAULT '23:59' COMMENT '观看时段结束时间 ，00:00~23:59',
  `watch_hours` tinyint(4) NOT NULL DEFAULT '24' COMMENT '允许观看时长（小时），24 = 不限制、1 = 一个小时、2 = 两个小时',
  `protect_eyes` tinyint(4) NOT NULL DEFAULT '0' COMMENT '护眼，0 = 不开启、1 = 开启',
  `lock` tinyint(4) NOT NULL DEFAULT '0' COMMENT '锁定，0 = 不锁定、1 = 锁定',
  `password` varchar(4) NOT NULL COMMENT '密码',
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_date` timestamp NULL DEFAULT NULL COMMENT '刷新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `deviceid` (`deviceid`),
  UNIQUE KEY `openid` (`openid`)
) ENGINE=InnoDB AUTO_INCREMENT=269 DEFAULT CHARSET=utf8 COMMENT='儿童模式设备配置表';

-- 数据导出被取消选择。
-- 导出  表 KKBUSINESS.childmode_operation_rec 结构
CREATE TABLE IF NOT EXISTS `childmode_operation_rec` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键，自增id',
  `deviceid` int(11) NOT NULL COMMENT '设备id',
  `operation_type` tinyint(4) NOT NULL COMMENT '操作类型，0 = 开机、1 = 关机、2 = 开机失败',
  `operation_time` timestamp NULL DEFAULT NULL COMMENT '操作时间',
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2016 DEFAULT CHARSET=utf8 COMMENT='儿童模式设备操作记录表';

-- 数据导出被取消选择。
-- 导出  表 KKBUSINESS.childmode_operation_rec_backup 结构
CREATE TABLE IF NOT EXISTS `childmode_operation_rec_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键，自增id',
  `deviceid` int(11) NOT NULL COMMENT '设备id',
  `operation_type` tinyint(4) NOT NULL COMMENT '操作类型，0 = 开机、1 = 关机、2 = 开机失败',
  `operation_time` timestamp NULL DEFAULT NULL COMMENT '操作时间',
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1732 DEFAULT CHARSET=utf8 COMMENT='儿童模式设备操作记录表';

-- 数据导出被取消选择。
-- 导出  表 KKBUSINESS.childmode_watch_rec 结构
CREATE TABLE IF NOT EXISTS `childmode_watch_rec` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键，自增id',
  `deviceid` int(11) NOT NULL COMMENT '设备id',
  `watch_minutes` int(11) NOT NULL COMMENT '观看的时间长度（分钟）0~1440',
  `watch_date` timestamp NULL DEFAULT NULL COMMENT '观看的日期',
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1093 DEFAULT CHARSET=utf8 COMMENT='儿童模式设备观看记录表';

-- 数据导出被取消选择。
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
